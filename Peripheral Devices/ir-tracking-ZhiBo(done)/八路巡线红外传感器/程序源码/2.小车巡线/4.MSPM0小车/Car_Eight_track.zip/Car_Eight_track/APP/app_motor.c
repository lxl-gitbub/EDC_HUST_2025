#include "app_motor.h"


extern volatile int32_t gEncoderCount_L1,gEncoderCount_L2;
extern volatile int32_t gEncoderCount_R1 ,gEncoderCount_R2;

pid_t pid_motor[4];

int Encoder_speed_offset[4] = {0};
int Encoder_speed_last[4] = {0};
int Encoder_speed_now[4] = {0};

uint8_t g_start_ctrl = 0;
car_data_t car_data;
motor_data_t motor_data;

// ��ȡ�����������ܹ�����·������������
void Encoder_Get_ALL(int* Encoder_all)
{
			Encoder_all[0] -= gEncoderCount_L1;
			Encoder_all[1] -= gEncoderCount_L2;
			
			Encoder_all[2] += gEncoderCount_R1;
			Encoder_all[3] += gEncoderCount_R2;
			
			gEncoderCount_L1 = 0;//��0
			gEncoderCount_L2 = 0;//��0
			gEncoderCount_R1 = 0;//��0
			gEncoderCount_R2 = 0;//��0
}

// ��ȡ���������ݣ�������ƫ��������
void Motion_Get_Encoder(void)
{
    Encoder_Get_ALL(Encoder_speed_now);

    for(uint8_t i = 0; i < Motor_MAX; i++)
    {
        // ��¼���β���ʱ����������
        Encoder_speed_offset[i] = Encoder_speed_now[i] - Encoder_speed_last[i];
	    // ��¼�ϴα���������
	    Encoder_speed_last[i] = Encoder_speed_now[i];
    
    }
}


//���ر���������
static  float Motion_Get_Circle_Pulse(void)
{  
    return ENCODER_CIRCLE_450;
}

// ���ص�ǰС����������͵�һ��
static float Motion_Get_APB(void)
{
    return STM32Car_APB;
}

// ���ص�ǰС������תһȦ�Ķ��ٺ���
static float Motion_Get_Circle_MM(void)
{
		return WHEEL_CIRCLE_MM; 
}



void Motor_PID_Init(void)
{
	for (int i = 0; i < Motor_MAX; i++)
	{
			pid_motor[i].target_val = 0.0;
			pid_motor[i].pwm_output = 0.0;
			pid_motor[i].err = 0.0;
			pid_motor[i].err_last = 0.0;
			pid_motor[i].err_next = 0.0;
			pid_motor[i].integral = 0.0;

			pid_motor[i].Kp = MOTOR_P;
			pid_motor[i].Ki = MOTOR_I;
			pid_motor[i].Kd = MOTOR_D;
	}


}


// ����PIDĿ���ٶȣ���λΪ��mm/s
void PID_Set_Motor_Target(uint8_t motor_id, float target)
{
    if (motor_id > Motor_MAX) return;

    if (motor_id == Motor_MAX)
    {
        for (int i = 0; i < Motor_MAX; i++)
        {
            pid_motor[i].target_val = target;
        }
    }
    else
    {
        pid_motor[motor_id].target_val = target;
    }
}

// ���PID����
void PID_Clear_Motor(uint8_t motor_id)
{
    if (motor_id > Motor_MAX) return;

    if (motor_id == Motor_MAX)
    {
        for (int i = 0; i < Motor_MAX; i++)
        {
            pid_motor[i].pwm_output = 0.0;
            pid_motor[i].err = 0.0;
            pid_motor[i].err_last = 0.0;
            pid_motor[i].err_next = 0.0;
            pid_motor[i].integral = 0.0;
        }
    }
    else
    {
        pid_motor[motor_id].pwm_output = 0.0;
        pid_motor[motor_id].err = 0.0;
        pid_motor[motor_id].err_last = 0.0;
        pid_motor[motor_id].err_next = 0.0;
        pid_motor[motor_id].integral = 0.0;
    }
}



// ����ʽPID���㹫ʽ
float PID_Incre_Calc(pid_t *pid, float actual_val)
{
    /*����Ŀ��ֵ��ʵ��ֵ�����*/
    pid->err = pid->target_val - actual_val;
    /*PID�㷨ʵ��*/
    pid->pwm_output += pid->Kp *(pid->err - pid->err_next) 
                    + pid->Ki  * pid->err 
                    + pid->Kd  *(pid->err - 2 * pid->err_next + pid->err_last);
    /*�������*/
    pid->err_last = pid->err_next;
    pid->err_next = pid->err;
    
    /*����PWM���ֵ*/

		if (pid->pwm_output > (MOTOR_MAX_PULSE-MOTOR_IGNORE_PULSE))
				pid->pwm_output = (MOTOR_MAX_PULSE-MOTOR_IGNORE_PULSE);
		if (pid->pwm_output < (MOTOR_IGNORE_PULSE-MOTOR_MAX_PULSE))
				pid->pwm_output = (MOTOR_IGNORE_PULSE-MOTOR_MAX_PULSE);

    return pid->pwm_output;
}


// PID�������ֵ
void PID_Calc_Motor(motor_data_t* motor)
{
    int i;
       
    for (i = 0; i < Motor_MAX; i++)
    {
        motor->speed_pwm[i] = PID_Incre_Calc(&pid_motor[i], motor->speed_mm_s[i]);
    }
}



void Motion_Set_Speed(int16_t speed_m1, int16_t speed_m2, int16_t speed_m3, int16_t speed_m4)
{
		if(speed_m1 == 0 && speed_m2 == 0 && speed_m3 == 0 && speed_m4 ==0)
		{
			 Motion_Stop();
		}
		else
		{
			//��Ϊ��ë�̣���������һ��Ϊ0������pid����п��ƣ��ᵼ��ֹͣ���ˡ�
			//���Բ���if
				g_start_ctrl = 1;
		}
			
			
    motor_data.speed_set[0] = speed_m1;
    motor_data.speed_set[1] = speed_m2;
    motor_data.speed_set[2] = speed_m3;
    motor_data.speed_set[3] = speed_m4;
    for (uint8_t i = 0; i < Motor_MAX; i++)
    {
        PID_Set_Motor_Target(i, motor_data.speed_set[i]*1.0);
    }
}


// �ӱ�������ȡ��ǰ�������ٶȣ���λmm/s
void Motion_Get_Speed(car_data_t* car)
{
    int i = 0;
    float speed_mm[Motor_MAX] = {0};
    float circle_mm = Motion_Get_Circle_MM();
    float circle_pulse = Motion_Get_Circle_Pulse();
    float robot_APB = Motion_Get_APB();

    Motion_Get_Encoder();

    // ���������ٶȣ���λmm/s��
    for (i = 0; i < 4; i++)
    {
        speed_mm[i] = (Encoder_speed_offset[i]) * 100 * circle_mm / circle_pulse;
    }
		
		 car->Vx = (speed_mm[0] + speed_mm[1] + speed_mm[2] + speed_mm[3]) / 4;
     car->Vy = 0;
     car->Vz = -(speed_mm[0] + speed_mm[1] - speed_mm[2] - speed_mm[3]) / 4.0f / robot_APB * 1000;
		
		if (g_start_ctrl)
    {
        PID_Calc_Motor(&motor_data);
		}
}

// С��ֹͣ
void Motion_Stop(void)
{
    Motion_Set_Speed(0, 0, 0, 0);
    PID_Clear_Motor(Motor_MAX);
    g_start_ctrl = 0;
	
    Motion_Set_Pwm(0,0,0,0);
}


static float speed_lr = 0;
static float speed_fb = 0;
static float speed_spin = 0;
static int speed_L1_setup = 0;
static int speed_L2_setup = 0;
static int speed_R1_setup = 0;
static int speed_R2_setup = 0;

void wheel_Ctrl(int16_t V_x, int16_t V_y, int16_t V_z)  //Ѳ��PIDֱ�������ֵ
{
    float robot_APB = Motion_Get_APB();
//    speed_lr = -V_y;
		speed_lr = 0;
    speed_fb = V_x;
    speed_spin = (V_z / 1000.0f) * robot_APB;
    if (V_x == 0 && V_y == 0 && V_z == 0)
    {
        Motion_Stop();
        return;
    }

    speed_L1_setup = speed_fb + speed_lr + speed_spin;
    speed_L2_setup = speed_fb - speed_lr + speed_spin;
    speed_R1_setup = speed_fb - speed_lr - speed_spin;
    speed_R2_setup = speed_fb + speed_lr - speed_spin;
		
		if (speed_L1_setup > 1000) speed_L1_setup = 1000;
		if (speed_L1_setup < -1000) speed_L1_setup = -1000;
		if (speed_L2_setup > 1000) speed_L2_setup = 1000;
		if (speed_L2_setup < -1000) speed_L2_setup = -1000;
		if (speed_R1_setup > 1000) speed_R1_setup = 1000;
		if (speed_R1_setup < -1000) speed_R1_setup = -1000;
		if (speed_R2_setup > 1000) speed_R2_setup = 1000;
		if (speed_R2_setup < -1000) speed_R2_setup = -1000;
		
		//printf("%d\t,%d\t,%d\t,%d\r\n",speed_L1_setup,speed_L2_setup,speed_R1_setup,speed_R2_setup);
		
		Motion_Set_Speed(speed_L1_setup, speed_L2_setup, speed_R1_setup, speed_R2_setup);
		
	}
		
		
// �˶����ƾ����ÿ10ms����һ�Σ���Ҫ�����ٶ���ص�����
void Motion_Handle(void)
{
    Motion_Get_Speed(&car_data);

    if (g_start_ctrl)
    {
        Motion_Set_Pwm(motor_data.speed_pwm[0], motor_data.speed_pwm[1], motor_data.speed_pwm[2], motor_data.speed_pwm[3]);
    }
}


//ֱ�ӿ���pwm
void motion_car_control(int16_t V_x, int16_t V_y, int16_t V_z)
{
	float robot_APB = Motion_Get_APB();
		speed_lr = 0;
    speed_fb = V_x;
    speed_spin = (V_z / 1000.0f) * robot_APB;
    if (V_x == 0 && V_y == 0 && V_z == 0)
    {
        Motion_Set_Pwm(0,0,0,0);
        return;
    }

    speed_L1_setup = speed_fb + speed_spin;
    speed_L2_setup = speed_fb + speed_spin;
    speed_R1_setup = speed_fb  - speed_spin;
    speed_R2_setup = speed_fb  - speed_spin;
		
		if (speed_L1_setup > 1000) speed_L1_setup = 1000;
		if (speed_L1_setup < -1000) speed_L1_setup = -1000;
		if (speed_L2_setup > 1000) speed_L2_setup = 1000;
		if (speed_L2_setup < -1000) speed_L2_setup = -1000;
		if (speed_R1_setup > 1000) speed_R1_setup = 1000;
		if (speed_R1_setup < -1000) speed_R1_setup = -1000;
		if (speed_R2_setup > 1000) speed_R2_setup = 1000;
		if (speed_R2_setup < -1000) speed_R2_setup = -1000;
		
		//printf("%d\t,%d\t,%d\t,%d\r\n",speed_L1_setup,speed_L2_setup,speed_R1_setup,speed_R2_setup);
		
		Motion_Set_Pwm(speed_L1_setup, speed_L2_setup, speed_R1_setup, speed_R2_setup);
		
}



