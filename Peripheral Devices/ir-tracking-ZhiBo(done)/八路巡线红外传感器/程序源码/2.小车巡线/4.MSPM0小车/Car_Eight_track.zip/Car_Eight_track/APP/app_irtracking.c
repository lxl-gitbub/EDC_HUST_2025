#include "app_irtracking.h"

//Ѳ��̽ͷ�Ĵ���
static void track_deal_four(u8 *s1,u8 *s2,u8 *s3,u8 *s4,u8 *s5,u8 *s6,u8 *s7,u8 *s8)
{
	*s1 = DL_GPIO_readPins(IR_X_X1_PORT, IR_X_X1_PIN) > 0 ? 1 : 0;;
	*s2 = DL_GPIO_readPins(IR_X_X2_PORT, IR_X_X2_PIN) > 0 ? 1 : 0;;
	*s3 = DL_GPIO_readPins(IR_X_X3_PORT, IR_X_X3_PIN) > 0 ? 1 : 0;;
	*s4 = DL_GPIO_readPins(IR_X_X4_PORT, IR_X_X4_PIN) > 0 ? 1 : 0;;
	
	*s5 = DL_GPIO_readPins(IR_X_X5_PORT, IR_X_X5_PIN) > 0 ? 1 : 0;;
	*s6 = DL_GPIO_readPins(IR_X_X6_PORT, IR_X_X6_PIN) > 0 ? 1 : 0;;
	*s7 = DL_GPIO_readPins(IR_X_X7_PORT, IR_X_X7_PIN) > 0 ? 1 : 0;;
	*s8 = DL_GPIO_readPins(IR_X_X8_PORT, IR_X_X8_PIN) > 0 ? 1 : 0;;
}



/*************************PID*��PID����Ѳ����********************************/

//pid_t pid_IRR;
////����PID
//#define IRR_PID_KP       (0) //������ǽӽ���õĲ���
//#define IRR_PID_KI       (0)
//#define IRR_PID_KD       (0)//kp�̶������ �������ϵ�


#define IRTrack_Trun_KP (250) //350 490  250
#define IRTrack_Trun_KI (0) 
#define IRTrack_Trun_KD (1) 

int pid_output_IRR = 0;

#define IRR_SPEED 			  400  //Ѳ���ٶ�
#define IRTrack_Minddle    0 //�м��ֵ


float APP_ELE_PID_Calc(int8_t actual_value)
{

	float IRTrackTurn = 0;
	int8_t error;
	static int8_t error_last=0;
	static float IRTrack_Integral;//����
	

	error=actual_value-IRTrack_Minddle;
	
	IRTrack_Integral +=error;
	
	//	//λ��ʽpid
	IRTrackTurn=error*IRTrack_Trun_KP
							+IRTrack_Trun_KI*IRTrack_Integral
							+(error - error_last)*IRTrack_Trun_KD;
	return IRTrackTurn;
}

u8 trun_flag = 0; //0��û���� 1������
//x1-x8 ����������
void LineWalking(void)
{
	static int8_t err = 0;
	static u8 x1,x2,x3,x4,x5,x6,x7,x8;
	
	track_deal_four(&x1,&x2,&x3,&x4,&x5,&x6,&x7,&x8);
	
	//debug
//	static char bufbuf[30]={'\0'};
//	sprintf(bufbuf,"%d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t \r\n",x1,x2,x3,x4,x5,x6,x7,x8);
//	uart0_send_string((char*)bufbuf);
	
//�����ж�
	if(x1 == 1 && x2 == 1 &&x3 == 0 &&  x4 == 0  && x5 == 0 && x6  == 0 && x7 == 1 && x8 == 1 ) //�����
	{
		err = 15; 
	}
	else if(x1 == 1 && x2 == 1 &&x3 == 1 &&  x4 == 1  && x5 == 1 && x6  == 1 && x7 == 1 && x8 == 1 ) //�����
	{
		if(trun_flag == 0) //������
		{
			err = 15; 
			trun_flag = 1;
		}
		//������������ϸ�״̬
	}
	
  else if(x1 == 0 &&  x2 == 0  && x7 == 0 && x8 == 0 ) //���߶�����ֱ��
	{
		err = 0;
		if(trun_flag == 1)
		{
			trun_flag = 0;//�ߵ�Ȧ��
		}
	}
	
	//�����ж�
 else if(x1 == 0 &&  x3 == 0 && x4 == 0 && x5 == 0 && x8 == 0 )
	{
		err = 0;
	}
	//����ֱ��
	else if((x1 == 0 || x2 == 0 ) && x8 == 1) 
	{
		err = -15; 
	}
	//����ֱ��
	else if((x7 == 0 ||  x8 == 0) && x1 == 1) 
	{
		err = 15 ;
	}
	


	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 0 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1110 1111
	{
		err = -1;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 0&& x4 == 0 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1100 1111
	{
		err = -2;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 0&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1101 1111
	{
		err = -2;
	}
	
//	else if(x1 == 1 && x2 == 0  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1011 1111
//	{
//		err = -3;
//	}
	else if(x1 == 1 && x2 == 0  && x3 == 0&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1001 1111
	{
		err = -3;
	}
//		else if(x1 == 0 && x2 == 0  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 0011 1111
//	{
//		err = -4;   //ע�ͣ�����ֱ�Ǵ���
//	}
//	else if(x1 == 0 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 0111 1111
//	{
//		err = -5; //ע�ͣ�����ֱ�Ǵ���
//	}

	

	
	
	
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 0 && x6 == 1  && x7 == 1 && x8 == 1) // 1111 0111
	{
		err = 1;
	} 
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 0 && x6 == 0  && x7 == 1 && x8 == 1) // 1111 0011
	{
		err = 2;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 0  && x7 == 1 && x8 == 1) // 1111 1011
	{
		err = 2;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 0  && x7 == 0 && x8 == 1) // 1111 1001
	{
		err = 3;
	}
	
//	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 0 && x8 == 1) // 1111 1101
//	{
//		err = 3;
//	}
//	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 0 && x8 == 0) // 1111 1100
//	{
//		err = 4; ///����ֱ�Ǵ���
//	}
//		else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 0) // 1111 1110
//	{
//		err = 5; //����ֱ�Ǵ���
//	}
	

	
 
	else if(x1 == 1 &&x2 == 1 &&x3 == 1 && x4 == 0 && x5 == 0 && x6 == 1 && x7 == 1&& x8 == 1) //ֱ��
	{
		err = 0;
	}
	
	
	
	//ʣ�µľͱ�����һ��״̬	
	pid_output_IRR = (int)(APP_ELE_PID_Calc(err));

	motion_car_control(IRR_SPEED, 0, pid_output_IRR);

}

