#ifndef __ALLHeader_H_
#define __ALLHeader_H_

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "ti_msp_dl_config.h"
#include "bsp_at8236.h"
#include "bsp_delay.h"
#include "bsp_usart.h"


#include "app_motor.h"
#include "app_usart.h"
#include "app_irtracking.h"


#endif

