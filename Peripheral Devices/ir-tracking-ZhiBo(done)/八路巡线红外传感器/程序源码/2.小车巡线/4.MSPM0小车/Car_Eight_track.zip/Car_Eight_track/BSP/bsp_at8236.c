#include "bsp_at8236.h"


static int16_t Motor_Ignore_Dead_Zone(int16_t pulse)
{
   
		if (pulse > 0) return pulse + MOTOR_IGNORE_PULSE;
		if (pulse < 0) return pulse - MOTOR_IGNORE_PULSE;

    return 0;
}


void init_motor(void)
{
	DL_TimerA_startCounter(PWM_L1_INST);
	DL_TimerA_startCounter(PWM_L2_INST);
	DL_TimerA_startCounter(PWM_R1_INST);
	DL_TimerA_startCounter(PWM_R2_INST);
}


void L1_control(uint16_t motor_speed,uint8_t dir)
{
	if(dir)
	{
			DL_TimerA_setCaptureCompareValue(PWM_L1_INST, motor_speed, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_L1_INST, 0, DL_TIMER_CC_1_INDEX);
	}
	else
	{
			DL_TimerA_setCaptureCompareValue(PWM_L1_INST, 0, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_L1_INST, motor_speed, DL_TIMER_CC_1_INDEX);
	}

}



void L2_control(uint16_t motor_speed,uint8_t dir)
{
	if(dir)
	{
			DL_TimerA_setCaptureCompareValue(PWM_L2_INST, motor_speed, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_L2_INST, 0, DL_TIMER_CC_1_INDEX);
	}
	else
	{
			DL_TimerA_setCaptureCompareValue(PWM_L2_INST, 0, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_L2_INST, motor_speed, DL_TIMER_CC_1_INDEX);
	}
		
}

void R1_control(uint16_t motor_speed,uint8_t dir)
{
	if(dir)
	{
			DL_TimerA_setCaptureCompareValue(PWM_R1_INST, motor_speed, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_R1_INST, 0, DL_TIMER_CC_1_INDEX);
			
	}
	else
	{
			DL_TimerA_setCaptureCompareValue(PWM_R1_INST, 0, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_R1_INST, motor_speed, DL_TIMER_CC_1_INDEX);
	}
		
}


void R2_control(uint16_t motor_speed,uint8_t dir)
{
	if(dir)
	{
			DL_TimerA_setCaptureCompareValue(PWM_R2_INST, 0, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_R2_INST, motor_speed, DL_TIMER_CC_1_INDEX);
	}
	else
	{
			DL_TimerA_setCaptureCompareValue(PWM_R2_INST, motor_speed, DL_TIMER_CC_0_INDEX);
			DL_TimerA_setCaptureCompareValue(PWM_R2_INST, 0, DL_TIMER_CC_1_INDEX);
	}
		
}



// ����С���˶���Motor_X=[-3600, 3600]��������Χ����Ч��
void Motion_Set_Pwm(int16_t Motor_1, int16_t Motor_2, int16_t Motor_3, int16_t Motor_4)
{
    if (Motor_1 >= -MOTOR_MAX_PULSE && Motor_1 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(Motor_M1, Motor_1);
    }
    if (Motor_2 >= -MOTOR_MAX_PULSE && Motor_2 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(Motor_M2, Motor_2);
    }
    if (Motor_3 >= -MOTOR_MAX_PULSE && Motor_3 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(Motor_M3, Motor_3);
    }
    if (Motor_4 >= -MOTOR_MAX_PULSE && Motor_4 <= MOTOR_MAX_PULSE)
    {
        Motor_Set_Pwm(Motor_M4, Motor_4);
    }
}


// ���õ���ٶȣ�speed:��3600, 0Ϊֹͣ
void Motor_Set_Pwm(uint8_t id, int16_t speed)
{
    int16_t pulse = Motor_Ignore_Dead_Zone(speed);
    // ��������
    if (pulse >= MOTOR_MAX_PULSE)
        pulse = MOTOR_MAX_PULSE;
    if (pulse <= -MOTOR_MAX_PULSE)
        pulse = -MOTOR_MAX_PULSE;

    switch (id)
    {
    case Motor_M1:
    {
        if (pulse >= 0)
        {
            DL_TimerA_setCaptureCompareValue(PWM_L1_INST, pulse, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_L1_INST, 0, DL_TIMER_CC_1_INDEX);
        }
        else
        {
					pulse = -pulse; //�Ѹ���ת������
            DL_TimerA_setCaptureCompareValue(PWM_L1_INST, 0, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_L1_INST, pulse, DL_TIMER_CC_1_INDEX);
        }
        break;
    }
    case Motor_M2:
    {
        if (pulse >= 0)
        {
						DL_TimerA_setCaptureCompareValue(PWM_L2_INST, pulse, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_L2_INST, 0, DL_TIMER_CC_1_INDEX);
				}
				else
				{
						pulse = -pulse; //�Ѹ���ת������
						DL_TimerA_setCaptureCompareValue(PWM_L2_INST, 0, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_L2_INST, pulse, DL_TIMER_CC_1_INDEX);
				}
        break;
    }

    case Motor_M3:
    {
        if (pulse >= 0)
        {
						DL_TimerA_setCaptureCompareValue(PWM_R1_INST, pulse, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_R1_INST, 0, DL_TIMER_CC_1_INDEX);
						
				}
				else
				{
						pulse = -pulse; //�Ѹ���ת������
						DL_TimerA_setCaptureCompareValue(PWM_R1_INST, 0, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_R1_INST, pulse, DL_TIMER_CC_1_INDEX);
				}
        break;
    }
    case Motor_M4:
    {
        if (pulse >= 0)
				{
						DL_TimerA_setCaptureCompareValue(PWM_R2_INST, 0, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_R2_INST, pulse, DL_TIMER_CC_1_INDEX);
				}
				else
				{
						pulse = -pulse; //�Ѹ���ת������
						DL_TimerA_setCaptureCompareValue(PWM_R2_INST, pulse, DL_TIMER_CC_0_INDEX);
						DL_TimerA_setCaptureCompareValue(PWM_R2_INST, 0, DL_TIMER_CC_1_INDEX);
				}
        break;
    }

    default:
        break;
    }
}
