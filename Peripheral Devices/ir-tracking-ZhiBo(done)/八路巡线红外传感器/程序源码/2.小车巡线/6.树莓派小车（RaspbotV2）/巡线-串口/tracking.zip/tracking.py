#!/usr/bin/python
# -*- coding:utf-8 -*-
import serial
from Raspbot_Lib import Raspbot
import time
import PID

#初始化pid
P = 6
I = 0
D = 0
middle_error = 0 #中心
go_speed = 20
IR_track_PID = PID.PositionalPID(P, I, D) #PID参数

#打开串口
ser = serial.Serial("/dev/ttyAMA0",115200,8,'N',1,timeout = 0.5) #树莓派引脚的串口
#ser = serial.Serial("/dev/ttyUSB0",115200,8,'N',1,timeout = 0.5) 

bot = Raspbot()#创建小车
print("put down Key1 Start!!!")

# #等待key1按下开始巡线
# key_down= False
# while True:
#     data = bot.read_data_array(0x0d, 1)
#     state=data[0]
#     if state == 1 and not key_down:
#         key_down = True  
#         break #跳出去 ,开始巡线

recv_cmd_buf = "$0,0,1#" #只接收数字型字符
ser.write(bytes(recv_cmd_buf,'utf-8'))



#接收相关变量
rxstep = 0
rxstart_flag = 0 #0：没接收  1:开始
rxBuff = "" #字符串

IR_Data_number = [0,0,0,0,0,0,0,0] #初始化

MAX_Speed = 100 #最大的速度 -看情况加大

# 控制电机运动 Control motor movement
def run_motor(M1,M2,M3,M4):  #-255~255
    bot.Ctrl_Muto(0, M1)
    bot.Ctrl_Muto(1, M2)
    bot.Ctrl_Muto(2, M3)
    bot.Ctrl_Muto(3, M4)

def limin_speed(speed,max,min):
    if speed > max:
        return max
    
    elif speed<min:
        return min

    return speed

#传入参数 x 和 y轴
def control_motor_speed(speed_fb,speed_lr):
    speed_L1 = speed_fb + speed_lr 
    speed_L2 = speed_fb + speed_lr 
    speed_R1 = speed_fb - speed_lr 
    speed_R2 = speed_fb - speed_lr 
    #满足速度范围
    speed_L1 = limin_speed(speed_L1,MAX_Speed,-MAX_Speed)
    speed_L2 = limin_speed(speed_L2,MAX_Speed,-MAX_Speed)
    speed_R1 = limin_speed(speed_R1,MAX_Speed,-MAX_Speed)
    speed_R2 = limin_speed(speed_R2,MAX_Speed,-MAX_Speed)

    run_motor(speed_L1,speed_L2,speed_R1,speed_R2) #控制电机转


##############################################################
#数值赋值
def Data_Usart_Data():
    global rxBuff
    for i in range(8):
        IR_Data_number[i] = int((rxBuff[6+i*5]));#把字符转成数字 //6 11 16 21 26 
    

#接收数据处理
def Data_deal(rxtemp):
    global rxstep,rxstart_flag,rxBuff
    if rxstart_flag == 0:
        if rxtemp == "$":
            rxstart_flag = 1
            rxBuff = rxBuff + rxtemp
    else:
        rxBuff = rxBuff + rxtemp
        if rxtemp == '#':
            Data_Usart_Data()#进行赋值解算
            rxstart_flag = 0
            rxBuff = ""#清空数据

            GET_IR_data()#只有不停的接收到数据才会控制运动 

def usart_deal():
        data = ser.read(1)
        data = data.decode('utf-8')
        Data_deal(data)




#pid巡线处理
error = 0
def GET_IR_data():
    global error
    #print(IR_Data_number[0]) 
    x1 = IR_Data_number[0]
    x2 = IR_Data_number[1]
    x3 = IR_Data_number[2]
    x4 = IR_Data_number[3]
    x5 = IR_Data_number[4]
    x6 = IR_Data_number[5]
    x7 = IR_Data_number[6]
    x8 = IR_Data_number[7]

    if x1 == 1 and x2 == 1 and x3 == 1 and x4 == 0 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1:  # 1110 1111
        error = 1
    elif x1 == 1 and x2 == 1 and x3 == 0 and x4 == 0 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1: # 1100 1111
        error = 2
    elif x1 == 1 and x2 == 1 and x3 == 0 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1: # 1101 1111
        error = 2
    elif x1 == 1 and x2 == 0 and x3 == 0 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1: # 1001 1111
        error = 3
    elif x1 == 1 and x2 == 0 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1: # 1011 1111
        error = 3
    elif x1 == 0 and x2 == 0 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1: # 0011 1111
        error = 4
    elif x1 == 0 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 1: # 0111 1111
        error = 4

    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 0 and x6 == 1 and x7 == 1 and x8 == 1:  # 1111 0111
        error = -1
    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 0 and x6 == 0 and x7 == 1 and x8 == 1: # 1111 0011
        error = -2
    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 0 and x7 == 1 and x8 == 1: # 1111 1011
        error = -2
    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 0 and x7 == 0 and x8 == 1: # 1111 1001
        error = -3
    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 0 and x8 == 1: # 1111 1101
        error = -3
    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 0 and x8 == 0: # 1111 1100
        error = -4
    elif x1 == 1 and x2 == 1 and x3 == 1 and x4 == 1 and x5 == 1 and x6 == 1 and x7 == 1 and x8 == 0: # 1111 1110
        error = -4
    
    elif x4 == 0 and x5 == 0:
        error = 0 #直走

    #其它情况保持上一种状态

    

    #这里计算错误
    IR_track_PID.SystemOutput = error 
    IR_track_PID.SetStepSignal(middle_error)
    IR_track_PID.SetInertiaTime(0.01, 0.1)               
    speed_value = int(IR_track_PID.SystemOutput) #如果不好使 直接用 PidOutput的值
    #print(speed_value)
    #最后调用
    control_motor_speed(go_speed,speed_value)


#主函数
if __name__ == "__main__":
    print("start it")
    
    try:
        while True:
            usart_deal()
    except KeyboardInterrupt:
        pass
    finally:
       #停止运动
        bot.Ctrl_Car(0,1,0) #L1电机 后退 0速度
        bot.Ctrl_Car(1,1,0) #L2电机 后退 0速度
        bot.Ctrl_Car(2,1,0) #R1电机 后退 0速度
        bot.Ctrl_Car(3,1,0) #R2电机 后退 0速度
        ser.write(bytes("$0,0,0#",'utf-8'))
