#include "app_tracking.h"

//----------------PID-------------\\----//

#define Track_Speed 15  //�����ٶ�̫��,�ᶪ����,��������

#define IRTrack_Trun_KP (270) //265 //100-1000
#define IRTrack_Trun_KI (0.01) //0.01 0
#define IRTrack_Trun_KD (0.15) //0.2 0-2
#define IRTrack_Minddle  0

int8_t error = 0;

void Set_track_speed(void)
{
	Move_X = Track_Speed;       
}


void PID_track_get(void)
{
	static u8 x1,x2,x3,x4,x5,x6,x7,x8;

		
		x1 = IR_Data_number[0];
		x2 = IR_Data_number[1];
		x3 = IR_Data_number[2];
		x4 = IR_Data_number[3];
		x5 = IR_Data_number[4];
		x6 = IR_Data_number[5];
		x7 = IR_Data_number[6];
		x8 = IR_Data_number[7];

			//�����ж�
  if(x1 == 0 &&  x3 == 0 && x4 == 0 && x5 == 0 && x8 == 0 )
	{
		error = 0;
	}
	//����ֱ��
	else if((x1 == 0 || x2 == 0 ) && x8 == 1)  
	{
		error = -5; 
	}
	//����ֱ��
	else if((x7 == 0 ||  x8 == 0) && x1 == 1) 
	{
		error = 5 ;
	}
	
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 0 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1110 1111
	{
		error = -1;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 0&& x4 == 0 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1100 1111
	{
		error = -2;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 0&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1101 1111
	{
		error = -2;
	}
	
	else if(x1 == 1 && x2 == 0  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1011 1111
	{
		error = -3;
	}
	else if(x1 == 1 && x2 == 0  && x3 == 0&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 1001 1111
	{
		error = -3;
	}
	
	
	else if(x1 == 0 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 0111 1111
	{
		error = -4;  
	}
	else if(x1 == 0 && x2 == 0  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 1) // 0011 1111
	{
		error = -4; 
	}
	
	
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 0 && x6 == 1  && x7 == 1 && x8 == 1) // 1111 0111
	{
		error = 1;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 0 && x6 == 0  && x7 == 1 && x8 == 1) // 1111 0011
	{
		error = 2;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 0  && x7 == 1 && x8 == 1) // 1111 1011
	{
		error = 2;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 0  && x7 == 0 && x8 == 1) // 1111 1001
	{
		error = 3;
	}
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 0 && x8 == 1) // 1111 1101
	{
		error = 3;
	}
	
	else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 0 && x8 == 0) // 1111 1100
	{
		error = 4; 
	}
		else if(x1 == 1 && x2 == 1  && x3 == 1&& x4 == 1 && x5 == 1 && x6 == 1  && x7 == 1 && x8 == 0) // 1111 1110
	{
		error = 4; 
	}

	else if(x1 == 1 && x3 == 1 && x4 == 0 && x5 == 0  && x6 == 1 && x8 == 1) //ֱ��
	{
		error = 0;
	}
	
	
	
	
	
	
}


//pid
int Turn_IRTrack_PD(float gyro)
{

	int IRTrackTurn = 0;
	float err = 0;	
	static float IRTrack_Integral;
	
	PID_track_get();  //��ȡƫ�� Obtain deviation
	
	err=error-IRTrack_Minddle;
	
	IRTrack_Integral +=err;
	
  IRTrackTurn=err*IRTrack_Trun_KP+IRTrack_Trun_KI*IRTrack_Integral+gyro*IRTrack_Trun_KD;
	
	return IRTrackTurn;

}






