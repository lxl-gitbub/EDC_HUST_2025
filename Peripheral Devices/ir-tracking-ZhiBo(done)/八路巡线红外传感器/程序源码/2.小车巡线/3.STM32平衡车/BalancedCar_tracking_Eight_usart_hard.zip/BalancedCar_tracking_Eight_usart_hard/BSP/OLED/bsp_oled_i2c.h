#ifndef __BSP_OLED_I2C_H_
#define __BSP_OLED_I2C_H_

#include "AllHeader.h"


void OLED_I2C_Init(void);



//IIC���в�������
void OLED_IIC_Init(void);                  //��ʼ��IIC��IO��				 
int OLED_IIC_Start(void);                  //����IIC��ʼ�ź�
void OLED_IIC_Stop(void);                  //����IICֹͣ�ź�
void OLED_IIC_Send_Byte(uint8_t txd);           //IIC����һ���ֽ�
uint8_t OLED_IIC_Read_Byte(unsigned char ack);  //IIC��ȡһ���ֽ�
int OLED_IIC_Wait_Ack(void);               //IIC�ȴ�ACK�ź�
void OLED_IIC_Ack(void);                   //IIC����ACK�ź�
void OLED_IIC_NAck(void);                  //IIC������ACK�ź�

void OLED_IIC_Write_One_Byte(uint8_t daddr,uint8_t addr,uint8_t data);
uint8_t OLED_IIC_Read_One_Byte(uint8_t daddr,uint8_t addr);	 
unsigned char OLED_I2C_Readkey(unsigned char I2C_Addr);

unsigned char OLED_I2C_ReadOneByte(unsigned char I2C_Addr,unsigned char addr);
unsigned char OLED_IICwriteByte(unsigned char dev, unsigned char reg, unsigned char data);
uint8_t OLED_IICwriteBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data);
uint8_t OLED_IICwriteBits(uint8_t dev,uint8_t reg,uint8_t bitStart,uint8_t length,uint8_t data);
uint8_t OLED_IICwriteBit(uint8_t dev,uint8_t reg,uint8_t bitNum,uint8_t data);
uint8_t OLED_IICreadBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t *data);

int OLED_i2cWrite(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *data);
int OLED_i2cRead(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf);


#endif

