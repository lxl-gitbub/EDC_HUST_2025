#ifndef __INTSERVER_H_
#define __INTSERVER_H_

#include "ALLHeader.h"


void MPU6050_EXTI_Init(void);

//void TIM1_Init(void);



#endif

