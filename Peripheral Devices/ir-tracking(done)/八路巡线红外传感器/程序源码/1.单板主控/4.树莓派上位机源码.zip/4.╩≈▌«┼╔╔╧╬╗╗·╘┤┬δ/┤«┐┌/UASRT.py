#!/usr/bin/python
# -*- coding:utf-8 -*-
import serial
import time

#打开串口
ser = serial.Serial("/dev/ttyAMA0",115200,8,'N',1,timeout = 0.5) #树莓派引脚的串口
#ser = serial.Serial("/dev/ttyUSB0",115200,8,'N',1,timeout = 0.5) #usb转TTL模块


recv_cmd_buf = "$0,0,1#" #只接收数字型字符
ser.write(bytes(recv_cmd_buf,'utf-8'))



#接收相关变量
rxstep = 0
rxstart_flag = 0 #0：没接收  1:开始
rxBuff = "" #字符串

IR_Data_number = [0,0,0,0,0,0,0,0] #初始化



##############################################################
#数值赋值
def Data_Usart_Data():
    global rxBuff
    for i in range(8):
        IR_Data_number[i] = int((rxBuff[6+i*5]));#把字符转成数字 //6 11 16 21 26 
    

#接收数据处理
def Data_deal(rxtemp):
    global rxstep,rxstart_flag,rxBuff
    if rxstart_flag == 0:
        if rxtemp == "$":
            rxstart_flag = 1
            rxBuff = rxBuff + rxtemp
    else:
        rxBuff = rxBuff + rxtemp
        if rxtemp == '#':
            Data_Usart_Data()#进行赋值解算
            rxstart_flag = 0
            rxBuff = ""#清空数据

            GET_IR_data()#只有不停的接收到数据才会控制运动 

def usart_deal():
        data = ser.read(1)
        data = data.decode('utf-8')
        Data_deal(data)






def GET_IR_data():
    global error
    
    x1 = str(IR_Data_number[0])
    x2 = str(IR_Data_number[1])
    x3 = str(IR_Data_number[2])
    x4 = str(IR_Data_number[3])
    x5 = str(IR_Data_number[4])
    x6 = str(IR_Data_number[5])
    x7 = str(IR_Data_number[6])
    x8 = str(IR_Data_number[7])

    print("x1:"+x1+"  x2:"+x2+"  x3:"+x3+"  x4:"+x4+"  x5:"+x5+"  x6:"+x6+"  x7:"+x7+"  x8:"+x8) 

  



#主函数
if __name__ == "__main__":
    print("start it")
    
    try:
        while True:
            usart_deal()
    except KeyboardInterrupt:
        pass
    finally:
        ser.write(bytes("$0,0,0#",'utf-8'))
