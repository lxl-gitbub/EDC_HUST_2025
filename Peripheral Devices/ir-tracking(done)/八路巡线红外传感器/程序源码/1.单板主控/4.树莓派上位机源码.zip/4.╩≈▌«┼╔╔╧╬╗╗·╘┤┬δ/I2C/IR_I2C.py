import smbus
import time
 
# 定义I2C bus的编号，通常为0或1
i2c_bus_number = 1
 
# 创建I2C对象
bus = smbus.SMBus(i2c_bus_number)
 
# 定义I2C设备的地址
i2c_address = 0x12  # 示例地址
 
# 写入数据到I2C设备的指定寄存器
def write_to_i2c(register_address, data):
    bus.write_byte_data(i2c_address, register_address, data)
 
# 从I2C设备的指定寄存器读取数据
def read_from_i2c(register_address):
    return bus.read_byte_data(i2c_address, register_address)
 


write_to_i2c(0x01, 1)
time.sleep(1) #1s
write_to_i2c(0x01, 0)
time.sleep(1) #1s

#读取数据
while True:
    time.sleep(0.5) #500ms
    data = read_from_i2c(0x30)
    #print("i2cdata:"+str(data))
    x1 = str((data>>7)&0x01)
    x2 = str((data>>6)&0x01)
    x3 = str((data>>5)&0x01)
    x4 = str((data>>4)&0x01)
    x5 = str((data>>3)&0x01)
    x6 = str((data>>2)&0x01)
    x7 = str((data>>1)&0x01)
    x8 = str((data>>0)&0x01)
    print("x1:"+x1+"  x2:"+x2+"  x3:"+x3+"  x4:"+x4+"  x5:"+x5+"  x6:"+x6+"  x7:"+x7+"  x8:"+x8) 

    