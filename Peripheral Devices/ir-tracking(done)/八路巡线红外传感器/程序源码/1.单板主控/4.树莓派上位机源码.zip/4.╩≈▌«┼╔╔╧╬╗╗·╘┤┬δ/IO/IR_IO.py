import RPi.GPIO as GPIO
import time
 
# 设置GPIO模式
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
 
# 设置你想读取的引脚编号
x1 = 5   #GPIO.21
x2 = 6   #GPIO.22
x3 = 13  #GPIO.23
x4 = 19  #GPIO.24
x5 = 26  #GPIO.25

x6 = 16  #GPIO.27
x7 = 20  #GPIO.28
x8 = 21  #GPIO.29
 
# 设置引脚为输入
GPIO.setup(x1, GPIO.IN)
GPIO.setup(x2, GPIO.IN)
GPIO.setup(x3, GPIO.IN)
GPIO.setup(x4, GPIO.IN)
GPIO.setup(x5, GPIO.IN)
GPIO.setup(x6, GPIO.IN)
GPIO.setup(x7, GPIO.IN)
GPIO.setup(x8, GPIO.IN)

 
try:
    while True:
        # 读取引脚电平
        pin_state_x1 = GPIO.input(x1)
        pin_state_x2 = GPIO.input(x2)
        pin_state_x3 = GPIO.input(x3)
        pin_state_x4 = GPIO.input(x4)
        pin_state_x5 = GPIO.input(x5)
        pin_state_x6 = GPIO.input(x6)
        pin_state_x7 = GPIO.input(x7)
        pin_state_x8 = GPIO.input(x8)
        
        print("x1:"+str(pin_state_x1)+"  x2:"+str(pin_state_x2)+"  x3:"+str(pin_state_x3)+"  x4:"+str(pin_state_x4)+"  x5:"+str(pin_state_x5)+"  x6:"+str(pin_state_x6)+"  x7:"+str(pin_state_x7)+"  x8:"+str(pin_state_x8)) 
        # 等待一段时间
        time.sleep(1)

finally:
    # 清理GPIO设置
    GPIO.cleanup()