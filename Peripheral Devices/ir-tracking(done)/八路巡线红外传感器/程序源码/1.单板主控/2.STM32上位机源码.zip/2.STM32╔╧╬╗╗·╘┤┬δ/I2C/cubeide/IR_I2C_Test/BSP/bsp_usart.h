/*
 * bsp_usart.h
 *
 *  Created on: 2023年10月11日
 *      Author: YB-101
 */

#ifndef BSP_USART_H_
#define BSP_USART_H_

#include "stdio.h"
void Bsp_UART1_Init(void);

#endif /* BSP_USART_H_ */
