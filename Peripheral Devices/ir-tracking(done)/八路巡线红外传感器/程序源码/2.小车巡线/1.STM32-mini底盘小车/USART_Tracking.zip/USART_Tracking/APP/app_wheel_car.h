#ifndef __APP_WHEEL_CAR_H__
#define __APP_WHEEL_CAR_H__

#include "stdint.h"
#include "AllHeader.h"


// 底盘电机间距之和的一半
#define wheel_Car_APB                 (150.0f)

// 轮转一整圈的位移，单位为mm
#define wheel_Car_CIRCLE_MM            (204.203f)






void wheel_Ctrl(int16_t V_x, int16_t V_y, int16_t V_z);




#endif /* __APP_MECANUM_H__ */
