/**
* @par Copyright (C): 2016-2026, Shenzhen Yahboom Tech
* @file         // ALLHeader.h
* @author       // lly
* @version      // V1.0
* @date         // 230228
* @brief        // ������е�ͷ�ļ�
* @details      
* @par History  //
*               
*/


#ifndef __AllHeader_H
#define __AllHeader_H

#define DEBUG_USARTx USART1



#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "stdint.h"
#include "stm32f10x.h"
//#include "stm32f10x_gpio.h"
//#include "stm32f10x_pwr.h"
//#include "stm32f10x_bkp.h"

#include "bsp.h"
#include "bsp_common.h"
#include "delay.h"

#include "bsp_key.h"


#include "bsp_usart.h"


#include "bsp_encoder.h"
#include "bsp_motor.h"
#include "app_motion.h"
#include "bsp_pid.h"
#include "app_wheel_car.h"
#include "bsp_timer.h"

#include "app_usart.h"
#include "app_irtracking.h"



#endif


